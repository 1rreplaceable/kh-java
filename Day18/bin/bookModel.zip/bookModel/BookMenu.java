package bookModel;

import java.util.Scanner;

public class BookMenu {

	Scanner sc = new Scanner(System.in);
	BookController bc = new BookController();
	Book[] bArr;
	
	public BookMenu() {
		
	}
	public void mainMenu() {}
	
	public void fileSave() {}
	
	public void fileRead() {}
}


