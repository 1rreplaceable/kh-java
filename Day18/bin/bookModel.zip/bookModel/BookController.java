package bookModel;

public class BookController {

	BookDAO bd = new BookDAO();
	
	public void makeFile() {}
	
	public void fileSave(Book[] bArr) {
		
	}
	
	public Book[] fileRead() {}
}
