package bookModel;

public class BookDAO {

	Book[] bArr = new Book[10];
	public void fileSave(Book[] bArr) {}
	
	public Book[] fileRead() {}
}
